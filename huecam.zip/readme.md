**Virtual Bream VTuber. Requires UnityCapture**
(Docs will be here)